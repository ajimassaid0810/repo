import 'dart:ui';

const primaryColor = Color(0xFF7f593b);
const secondaryColor = Color(0xFF50554a);
